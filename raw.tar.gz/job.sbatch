#!/bin/bash
#SBATCH --job-name=sai-lammps-test
#SBATCH --partition=16V100
#SBATCH --qos=rush-gpu
#SBATCH --account=proj-sai-hpc-software
#SBATCH --nodes=2
#SBATCH --ntasks=8
#SBATCH --ntasks-per-node=4
#SBATCH --gres=gpu:4
#SBATCH --time=00:20:00
#SBATCH --chdir=/org/org-open-sai/proj-sai-hpc-software/lammps-daily-tester/runs/github-43686047999-1
#SBATCH --output=/org/org-open-sai/proj-sai-hpc-software/lammps-daily-tester/runs/github-43686047999-1/slurm-%j.log
#SBATCH --export=NIL
set -eo pipefail
export HOME=/home/stardust
export USER=${SLURM_JOB_USER:?} LOGNAME=${SLURM_JOB_USER:?}
export PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin
export LD_LIBRARY_PATH= LD_PRELOAD= PYTHONPATH=
export PYTHONDONTWRITEBYTECODE=1 PYTHONNOUSERSITE=1
export TMPDIR=/org/org-open-sai/proj-sai-hpc-software/lammps-daily-tester/runs/github-43686047999-1/scratch
export TMP="$TMPDIR" TEMP="$TMPDIR"
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export SLURM_EXPORT_ENV=ALL
export OMPI_MCA_plm_slurm_args=--external-launcher PRTE_MCA_plm_slurm_args=--external-launcher
unset PYTHONHOME APPTAINER_BIND APPTAINER_BINDPATH SINGULARITY_BIND SINGULARITY_BINDPATH
source /etc/profile.d/lmod.sh
module purge
module use /home/stardust/sai-hpc-software/modulefiles/apps
module load lammps/develop-beta-20261114-68b557e3a214-rf678a701a42f-bf68a67857441
module -t list > modules.txt 2>&1
scontrol show job -d "$SLURM_JOB_ID" > allocation.txt
export UCX_TLS='^cuda_ipc'
exec /usr/bin/python3 -B /org/org-open-sai/proj-sai-hpc-software/lammps-daily-tester/runs/github-43686047999-1/control/suite.py run /org/org-open-sai/proj-sai-hpc-software/lammps-daily-tester/runs/github-43686047999-1
